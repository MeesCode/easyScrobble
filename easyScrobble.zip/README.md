
Chrome extention to scrobble albums from their last.fm page <br/>
(find us in the chrome webstore)
<br/><br/>
To use this repo you should add a file "credentials.js" in the root directory containing this:

```
const API_KEY = "xxxxx";
const SERCRET = "xxxxx";
```

you can get these keys by creating a last.fm developer account

